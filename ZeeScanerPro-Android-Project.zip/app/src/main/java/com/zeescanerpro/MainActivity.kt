package com.zeescanerpro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private val executor = Executors.newSingleThreadExecutor()
    private var lastValue = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
        else startCamera()
    }

    override fun onRequestPermissionsResult(r:Int,p:Array<String>,g:IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r==10 && g.isNotEmpty() && g[0]==PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this,"Camera permission is required to scan.",Toast.LENGTH_LONG).show()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val previewUse = Preview.Builder().build().also { it.surfaceProvider = preview.surfaceProvider }
            val analyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analyzer.setAnalyzer(executor) { proxy ->
                val image = proxy.image
                if (image != null) {
                    val input = InputImage.fromMediaImage(image, proxy.imageInfo.rotationDegrees)
                    BarcodeScanning.getClient().process(input)
                        .addOnSuccessListener { codes ->
                            codes.firstOrNull()?.rawValue?.let { value ->
                                if (value != lastValue) {
                                    lastValue=value
                                    runOnUiThread {
                                        Toast.makeText(this, "Scanned: $value", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }.addOnCompleteListener { proxy.close() }
                } else proxy.close()
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUse, analyzer)
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() { executor.shutdown(); super.onDestroy() }
}

# ZeeScanerPro
A simple free Android barcode/QR scanner starter app.

Features:
- Camera scanning
- Google ML Kit barcode recognition
- QR, EAN/UPC, Code 128 and other ML Kit-supported formats
- No ads in this starter build

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Run on an Android phone with camera permission.

For a Play Store release, add a privacy policy, app icon, store listing, testing, and any monetization such as AdMob only after the basic scanner is working.
